$(document).ready(function(){
    $('.buttn').click(function(){
        $(this).next('.drop').slideToggle();
    });
});

